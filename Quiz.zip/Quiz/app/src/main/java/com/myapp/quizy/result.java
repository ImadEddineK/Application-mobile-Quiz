package com.myapp.quizy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.startapp.sdk.adsbase.StartAppSDK;


public class result extends AppCompatActivity {

    TextView result ;
    TextView tv2;
    TextView tv4;
    ImageView emoji;
    ImageView home,share,aboutt;
    int icon;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StartAppSDK.init(this, "206481415", true);
        setContentView(R.layout.activity_result);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);






        result=findViewById(R.id.result);
        tv2=findViewById(R.id.tv2);
        tv4=findViewById(R.id.tv4);
        emoji =findViewById(R.id.emoji);
        home=findViewById(R.id.homee);
        share=findViewById(R.id.share);
        aboutt=findViewById(R.id.aboutt);



        int i=a2.numberright;
        int j=country.countryright;
        if(category.category==3){tv2.setText("17");  result.setText(String.valueOf(j)); note(17,j); country.countryright=0;}
        else{result.setText(String.valueOf(i)); note(10,i); a2.numberright=0;}



        aboutt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                icon=1; goTo(icon);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                icon=2; goTo(icon);
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                icon=3;  goTo(icon);
            }
        });


    }




    public void note(int i,int j){
        if(i==17){
            if(j<4){emoji.setImageResource(R.drawable.toobad); tv4.setText("نتيجتك ضعيفة جدا تحتاج لتثقيف نفسك");}
            else if (j>=4 && j<7){emoji.setImageResource(R.drawable.bad); tv4.setText("نتيجة سيئة نوعا ما تحتاج المزيد من التثقيف");}
            else if (j>=7 && j<10){emoji.setImageResource(R.drawable.normal); tv4.setText("نتيجتك متوسطة");}
            else if (j>=10 && j<15){emoji.setImageResource(R.drawable.notbad); tv4.setText("نتيجتك جيدة");}
            else if (j>=15 && j<16){emoji.setImageResource(R.drawable.verygood); tv4.setText("نتيجتك جيدة جدا");}
            else if (j>=16){emoji.setImageResource(R.drawable.superr); tv4.setText("نتيجتك ممتازة");}
        }

       else if(i==10){
            if(j<2){emoji.setImageResource(R.drawable.toobad); tv4.setText("نتيجتك ضعيفة جدا تحتاج لتثقيف نفسك");}
            else if (j>=2 && j<4){emoji.setImageResource(R.drawable.bad); tv4.setText("نتيجة سيئة نوعا ما تحتاج المزيد من التثقيف");}
            else if (j>=4 && j<6){emoji.setImageResource(R.drawable.normal); tv4.setText("نتيجتك متوسطة");}
            else if (j>=6 && j<7){emoji.setImageResource(R.drawable.notbad); tv4.setText("نتيجتك جيدة");}
            else if (j>=7 && j<9){emoji.setImageResource(R.drawable.verygood); tv4.setText("نتيجتك جيدة جدا");}
            else if (j>=9){emoji.setImageResource(R.drawable.superr); tv4.setText("نتيجتك ممتازة");}
        }
    }


    public void goTo(int icon){

        if(icon ==1){
            Intent i=new Intent(this,about.class);
            startActivity(i);
        }
        else if (icon==2){
            Intent i=new Intent(this,MainActivity.class);
            startActivity(i);
        }
        else if (icon==3){
            try {
                Intent sharingintent=new Intent(Intent.ACTION_SEND);
                sharingintent.setType("text/plain");
                String sharbody="https://play.google.com/store/apps/details?="+BuildConfig.APPLICATION_ID+"\n\n";
                String sharsubject="تطبيق إختبار المعرفة";
                sharingintent.putExtra(Intent.EXTRA_TEXT,sharbody);
                sharingintent.putExtra(Intent.EXTRA_SUBJECT,sharsubject);
                startActivity(Intent.createChooser(sharingintent,"Share using"));
            } catch (Exception e){
                Toast.makeText(this,"جرب فيما بعد",Toast.LENGTH_SHORT).show();
            }
        }
    }

}
