package com.myapp.quizy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.startapp.sdk.adsbase.StartAppSDK;


public class country extends AppCompatActivity {

    public static int countryright=0;
    Button r12;
    Button r22;
    Button r32;
    Button r42;
    Button right;
    int pg=1;
    TextView page2;
    ImageView flag;
    Button next2;
    Button repeat2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StartAppSDK.init(this, "206481415", true);
        setContentView(R.layout.activity_country);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);




        r12=findViewById(R.id.r12);
        r22=findViewById(R.id.r22);
        r32=findViewById(R.id.r32);
        r42=findViewById(R.id.r42);
        flag= findViewById(R.id.flag);
        page2=findViewById(R.id.page2);
        next2=findViewById(R.id.next2);
        repeat2=findViewById(R.id.repeat2);

        repeat2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                repeat2();
            }
        });

        count();

        next2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                next();
            }
        });
    }


    public void count(){

        if(Integer.valueOf(page2.getText().toString())==1){
            flag.setImageResource(R.drawable.alg);
            r12.setText("الجزائر");
            r22.setText("عمان");
            r32.setText("فلسطين");
            r42.setText("المغرب");
            right=r12;
        }
        if(Integer.valueOf(page2.getText().toString())==2){
            flag.setImageResource(R.drawable.egy);
            r12.setText("الأردن");
            r22.setText("مصر");
            r32.setText("تونس");
            r42.setText("البحرين");
            right=r22;
        }
        if(Integer.valueOf(page2.getText().toString())==3){
            flag.setImageResource(R.drawable.bahrin);
            r12.setText("البحرين");
            r22.setText("السعودية");
            r32.setText("قطر");
            r42.setText("الكويت");
            right=r12;
        }
        if(Integer.valueOf(page2.getText().toString())==4){
            flag.setImageResource(R.drawable.belg);
            r12.setText("بريطانيا");
            r22.setText("ألمانيا");
            r32.setText("بلجيكا");
            r42.setText("فنلندا");
            right=r32;
        }
        if(Integer.valueOf(page2.getText().toString())==5){
            flag.setImageResource(R.drawable.canada);
            r12.setText("كندا");
            r22.setText("أمريكا");
            r32.setText("المكسيك");
            r42.setText("البرازيل");
            right=r12;
        }
        if(Integer.valueOf(page2.getText().toString())==6){
            flag.setImageResource(R.drawable.india);
            r12.setText("النيبال");
            r22.setText("الهند");
            r32.setText("إثيوبيا");
            r42.setText("ماليزيا");
            right=r22;
        }
        if(Integer.valueOf(page2.getText().toString())==7){
            flag.setImageResource(R.drawable.italy);
            r12.setText("النرويج");
            r22.setText("فرنسا");
            r32.setText("إيطاليا");
            r42.setText("فنلندا");
            right=r32;
        }
        if(Integer.valueOf(page2.getText().toString())==8){
            flag.setImageResource(R.drawable.japan);
            r12.setText("كوريا الشمالية");
            r22.setText("الصين");
            r32.setText("سنغافورة");
            r42.setText("اليابان");
            right=r42;
        }
        if(Integer.valueOf(page2.getText().toString())==9){
            flag.setImageResource(R.drawable.jib);
            r12.setText("جيبوتي");
            r22.setText("النيبال");
            r32.setText("ماليزيا");
            r42.setText("إسبانيا");
            right=r12;
        }
        if(Integer.valueOf(page2.getText().toString())==10){
            flag.setImageResource(R.drawable.jorden);
            r12.setText("فلسطين");
            r22.setText("الأردن");
            r32.setText("السعودية");
            r42.setText("قطر");
            right=r22;
        }
        if(Integer.valueOf(page2.getText().toString())==11){
            flag.setImageResource(R.drawable.lebanon);
            r12.setText("المغرب");
            r22.setText("سوريا");
            r32.setText("عمان");
            r42.setText("لبنان");
            right=r42;
        }
        if(Integer.valueOf(page2.getText().toString())==12){
            flag.setImageResource(R.drawable.lybie);
            r12.setText("ليبيا");
            r22.setText("موريتانيا");
            r32.setText("تونس");
            r42.setText("فلسطين");
            right=r12;
        }
        if(Integer.valueOf(page2.getText().toString())==13){
            flag.setImageResource(R.drawable.moritanie);
            r12.setText("النيجر");
            r22.setText("عمان");
            r32.setText("موريتانيا");
            r42.setText("المغرب");
            right=r32;
        }
        if(Integer.valueOf(page2.getText().toString())==14){
            flag.setImageResource(R.drawable.palestine);
            r12.setText("الأردن");
            r22.setText("عمان");
            r32.setText("فلسطين");
            r42.setText("المغرب");
            right=r32;
        }
        if(Integer.valueOf(page2.getText().toString())==15){
            flag.setImageResource(R.drawable.suiss);
            r12.setText("أكرانيا");
            r22.setText("سويسرا");
            r32.setText("أستراليا");
            r42.setText("كرواتيا");
            right=r22;
        }
        if(Integer.valueOf(page2.getText().toString())==16){
            flag.setImageResource(R.drawable.sau);
            r12.setText("السعودية");
            r22.setText("عمان");
            r32.setText("موريتانيا");
            r42.setText("المغرب");
            right=r12;
        }
        if(Integer.valueOf(page2.getText().toString())==17){
            flag.setImageResource(R.drawable.newziland);
            r12.setText("نيوزيلاندا");
            r22.setText("أستراليا");
            r32.setText("أمريكا");
            r42.setText("بريطانيا");
            right=r12;
        }


        //verify if correct
        r12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r12,right);
            }
        });
        r22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r22,right);
            }
        });
        r32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r32,right);
            }
        });
        r42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r42,right);
            }
        });



    }



    /////////////////////////////////////////////////////////////////////////////////
    //next question
    public void next(){
        r12.setBackgroundResource(R.drawable.custom_button);
        r22.setBackgroundResource(R.drawable.custom_button);
        r32.setBackgroundResource(R.drawable.custom_button);
        r42.setBackgroundResource(R.drawable.custom_button);
        pg=pg+1;
        if(pg==18){result();}
        else if(pg< 18){page2.setText(String.valueOf(pg)); count();}
        else if(pg>18){
            Toast.makeText(getApplicationContext(),"لقد أنهيت جميع الأسئلة",Toast.LENGTH_LONG).show();
        }

    }

    public void correct(Button b1, Button b2){
        if(b1.getId()==b2.getId()){
            countryright++;
            b2.setBackgroundColor(Color.GREEN);
        }
        else if(b1.getId()!=b2.getId()){
            b2.setBackgroundColor(Color.GREEN);
            b1.setBackgroundColor(Color.RED);
        }

    }

    public void result(){
        Intent i = new Intent(this, result.class);
        startActivity(i);
    }


    /////////////////////////////////////////////////////////////////////////
    //repeat2 button
    public void repeat2(){
        pg=1;
        page2.setText(String.valueOf(pg));
        countryright=0;
        count();
    }

}
