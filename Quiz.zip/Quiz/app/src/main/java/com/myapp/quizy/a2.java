package com.myapp.quizy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;



import com.startapp.sdk.adsbase.StartAppSDK;


public class a2 extends AppCompatActivity {

    private TextView quest;
    private Button right;
    public static int numberright=0;
    private Button r1;
    private Button r2;
    private Button r3;
    private Button r4;
    private TextView page;
    private int pg=1;
    private Button next;
    private TextView cat;
    Button repeat;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StartAppSDK.init(this, "206481415", true);
        setContentView(R.layout.activity_a2);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);






        quest=findViewById(R.id.quest);
        r1=findViewById(R.id.r1);
        r2=findViewById(R.id.r2);
        r3=findViewById(R.id.r3);
        r4=findViewById(R.id.r4);
        page=findViewById(R.id.page);
        next=findViewById(R.id.next);
        cat=findViewById(R.id.cat);
        repeat=findViewById(R.id.repeat);

        if(category.category==1){b1(); cat.setText("أسئلة عامة"); numberright=0;}
        else if(category.category==2){b2(); cat.setText("أسئلة دينية"); numberright=0;}

        else if(category.category==4){b4(); cat.setText("ألغاز"); numberright=0;}
        else if(category.category==5){b5(); cat.setText("أسئلة رياضية"); numberright=0;}


        repeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                repeat();
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                next();
            }
        });

    }



    //////////////////////////////////////////////////////////////////////////
    // generale questions
    public void b1(){
        if(Integer.valueOf(page.getText().toString())==1){
            quest.setText("أين توجد حاسة الشم عند الثعبان ؟");
            r1.setText("في الأذن");
            r2.setText("في اللسان");
            r3.setText("في الذيل");
            r4.setText("على الجلد");
            right=r2;
        }
        else if(Integer.valueOf(page.getText().toString())==2){
            quest.setText("ما الحيوان الذي ينام و إحدى عينيه مفتوحة ؟");
            r1.setText("الدرفيل");
            r2.setText("الدلفين");
            r3.setText("الأسد");
            r4.setText("الفقمة");
            right=r1;
        }
        else if(Integer.valueOf(page.getText().toString())==3){
            quest.setText("تصل مده حمل أنثى الفيل إلى…؟");
            r1.setText("12 شهر");
            r2.setText("18 شهر");
            r3.setText("22 شهرً");
            r4.setText("32 شهر");
            right=r3;
        }
        else if(Integer.valueOf(page.getText().toString())==4){
            quest.setText("الغاز الذي يشكل حوالي 75 %من اجمالي كتلة الشمس هو…؟");
            r1.setText("النتروجين ");
            r2.setText(" الأوكسجين ");
            r3.setText("الهيدروجينً");
            r4.setText("الكالسيوم");
            right=r3;
        }
        else if(Integer.valueOf(page.getText().toString())==5){
            quest.setText("الماء الذي يتجمد على نحو أسرع عند وضعه في داخل الفريزر هو…؟");
            r1.setText("الماء البارد");
            r2.setText("الماء الساخن");
            r3.setText("الماء المعتدلً");
            r4.setText("كلها في وقت واحد");
            right=r2;
        }
        else if(Integer.valueOf(page.getText().toString())==6){
            quest.setText("الطائر الوحيد الذي يستطيع تمييز اللون الأزرق هو ….؟");
            r1.setText("البومة ");
            r2.setText("الصقر");
            r3.setText("الغرابً");
            r4.setText("الهدهد");
            right=r1;
        }
        else if(Integer.valueOf(page.getText().toString())==7){
            quest.setText("اللون الذي لا يمكن للنحل رؤيته هو اللون…؟");
            r1.setText("الأبيض ");
            r2.setText("الأسود ");
            r3.setText("الأزرق ");
            r4.setText("البرتقالي");
            right=r1;
        }
        else if(Integer.valueOf(page.getText().toString())==8){
            quest.setText("من هوالعالم الفيزيائي الذي أكتشف القوانين الأساسية للتيار الكهربائي؟");
            r1.setText("جوزف برستلي");
            r2.setText("روبرت توماس مالتوس");
            r3.setText("الكسندر غراهام بيل");
            r4.setText("جورج أوهم");
            right=r4;
        }
        else if(Integer.valueOf(page.getText().toString())==9){
            quest.setText("ما أكبر دولة منتجة للكاكو في أفريقيا؟");
            r1.setText("السودان ");
            r2.setText("تشاد ");
            r3.setText("غانا");
            r4.setText("نيجيريا");
            right=r3;
        }
        else if(Integer.valueOf(page.getText().toString())==10){
            quest.setText("ما هي الطاقة التي يولدها البرق؟");
            r1.setText("مغناطيسية");
            r2.setText("كهربائية");
            r3.setText("كهرومغناطيسية");
            r4.setText("حرارية");
            right=r2;

        }

        //la reponse correct
        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r1,right);
            }
        });
        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r2,right);
            }
        });
        r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r3,right);
            }
        });
        r4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r4,right);
            }
        });

    }




    /////////////////////////////////////////////////////////////////////////////////////
    //religion
    public void b2(){

        if(Integer.valueOf(page.getText().toString())==1){
            quest.setText("كم عدد سور القرآن الكريم؟");
            r1.setText("118");
            r2.setText("117");
            r3.setText("119");
            r4.setText("114");
            right=r4;
        }
        else if(Integer.valueOf(page.getText().toString())==2){
            quest.setText("من هو النبي الذي ألقاه قومه في النار ؟");
            r1.setText("عيسى عليه السلام");
            r2.setText("إبراهيم  عليه السلام");
            r3.setText("موسى  عليه السلام");
            r4.setText("يونس  عليه السلام");
            right=r2;
        }
        else if(Integer.valueOf(page.getText().toString())==3){
            quest.setText("من هوأول صحابي حيّا الرسول صلى الله عليه وسلم بتحية الإسلام ؟");
            r1.setText("أبو بكر الصديق");
            r2.setText("أبو أيوب الأنصاري");
            r3.setText("أبو ذر الغفاري");
            r4.setText("أبو موسى الأشعري");
            right=r3;
        }
        else if(Integer.valueOf(page.getText().toString())==4){
            quest.setText("بدأت سورة الشعراء بعد البسملة بثلاثة حروف هي ؟");
            r1.setText("طسم");
            r2.setText("الم");
            r3.setText("الر");
            r4.setText("كهع");
            right=r1;
        }
        else if(Integer.valueOf(page.getText().toString())==5){
            quest.setText("من قائد المسلمين في معركة القادسية ؟");
            r1.setText("خالد بن الوليد");
            r2.setText("عمرو بن العاص");
            r3.setText("سعد بن أبي وقاص");
            r4.setText("شرحبيل بن حسنة");
            right=r3;
        }
        else if(Integer.valueOf(page.getText().toString())==6){
            quest.setText("الغزوة التي تسمى غزوة أوطاس أيضاَ هي غزوة..؟");
            r1.setText("بدر");
            r2.setText("بني قينقاع");
            r3.setText("مؤته");
            r4.setText("حنين");
            right=r4;
        }
        else if(Integer.valueOf(page.getText().toString())==7){
            quest.setText("ما أكثر سورة تكرر فيها أسم الرحمن ؟");
            r1.setText("سورة مريم");
            r2.setText("سورة الرحمن");
            r3.setText("سورة البقرة");
            r4.setText("سورة آل عمران");
            right=r1;
        }
        else if(Integer.valueOf(page.getText().toString())==8){
            quest.setText("هذا الدعاء(اللهم إني أعوذ بك من الخبث والخبائث)هو دعاء");
            r1.setText("دخول الحمام");
            r2.setText("الخروج من الحمام");
            r3.setText("دخول السوق");
            r4.setText("دخول القرية");
            right=r1;
        }
        else if(Integer.valueOf(page.getText().toString())==9){
            quest.setText("ما أخر سورة نزلت في مكة؟");
            r1.setText("النصر");
            r2.setText("القارعة");
            r3.setText("المرسلات");
            r4.setText("الزلزلة");
            right=r3;
        }
        else if(Integer.valueOf(page.getText().toString())==10){
            quest.setText("من هو الصحابي صاحب الهجرتين؟");
            r1.setText("أبو موسى الأشعري");
            r2.setText("جعفربن أبي طالب");
            r3.setText("القعقاع بن عمرو");
            r4.setText("عثمان بن عفان");
            right=r4;
        }


        //la reponse correct
        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r1,right);
            }
        });
        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r2,right);
            }
        });
        r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r3,right);
            }
        });
        r4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r4,right);
            }
        });
    }



    //////////////////////////////////////////////////////////////////////////
    //alghaz
    public void b4(){
        if(Integer.valueOf(page.getText().toString())==1){
            quest.setText("ما هو الشيئ الذي كلما زاد نقص؟");
            r1.setText("العمر");
            r2.setText("النار");
            r3.setText("الرمل");
            r4.setText("الحفرة");
            right=r1;
        }
        if(Integer.valueOf(page.getText().toString())==2){
            quest.setText("ما هو الشيئ الذي لا يمشي إلا بالضرب؟");
            r1.setText("القلم");
            r2.setText("المسمار");
            r3.setText("الحيوان");
            r4.setText("الدراجة");
            right=r2;
        }
        if(Integer.valueOf(page.getText().toString())==3){
            quest.setText("سار أربعة من الأولاد في صف فكانو أربعة أمام ولد و أربعة خلف ولد و ولد في الوسط , فكم كان عدد الأولاد؟");
            r1.setText("ثلاثة أولاد");
            r2.setText("ستة أولاد");
            r3.setText("خمسة أولاد");
            r4.setText("أربعة أولاد");
            right=r3;
        }
        if(Integer.valueOf(page.getText().toString())==4){
            quest.setText("كم شهر في السنة الميلادية يحتوي على 28 يوم؟");
            r1.setText("ثلاثة أشهر");
            r2.setText("12 أشهر");
            r3.setText("ستة أشهر");
            r4.setText("شهر واحد");
            right=r2;
        }
        if(Integer.valueOf(page.getText().toString())==5){
            quest.setText("صف من البط بطة بين بطتين وبطة خلفها بطتين وبطة أمامها بطتين كم عدد البط؟");
            r1.setText("4 بطات");
            r2.setText("3 بطات");
            r3.setText("5 بطات");
            r4.setText("بطتين");
            right=r2;
        }
        if(Integer.valueOf(page.getText().toString())==6){
            quest.setText("عائلة مؤلفة من 6 بنات وأخ لكل منهن ، فكم عدد أفراد العائلة؟");
            r1.setText("7 اشخاص");
            r2.setText("10 اشخاص");
            r3.setText("14 شخص");
            r4.setText("15 شخص");
            right=r1;
        }
        if(Integer.valueOf(page.getText().toString())==7){
            quest.setText("كم يظهر الرقم 9 من مرة من 0 إلى 100؟");
            r1.setText("9 مرات");
            r2.setText("10 مرات");
            r3.setText("11 مرة");
            r4.setText("20 مرة");
            right=r4;
        }
        if(Integer.valueOf(page.getText().toString())==8){
            quest.setText("يمان عمره 4 سنوات و أخوه محمد عنده نصف عمره , كم يصبح عمر محمد عندما يصير عمر يمان 100 سنة؟");
            r1.setText("50 سنة");
            r2.setText("40 سنة");
            r3.setText("98 سنة");
            r4.setText("90 سنة");
            right=r3;
        }
        if(Integer.valueOf(page.getText().toString())==9){
            quest.setText("شيء إذا وضعناه في الثلاجة لا يبرد فما هو؟" );
            r1.setText("الفلفل الحار");
            r2.setText("العدس");
            r3.setText("البيض");
            r4.setText("البصل");
            right=r1;
        }
        if(Integer.valueOf(page.getText().toString())==10){
            quest.setText("في طبق ثلاث تفاحات أخذت منهم تفاحتين كم تفاحة معك؟" );
            r1.setText("ثلاث");
            r2.setText("صفر");
            r3.setText("تفاحتين");
            r4.setText("تفاحة واحدة");
            right=r3;
        }

        //la reponse correct
        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r1,right);
            }
        });
        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r2,right);
            }
        });
        r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r3,right);
            }
        });
        r4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r4,right);
            }
        });

    }




    //////////////////////////////////////////////////////////////////////////
    //sport
    public void b5(){

        if(Integer.valueOf(page.getText().toString())==1){
            quest.setText("عدد اللاعبين لكل فريق في هذه اللعبة 11 لاعب، والتبديل فيها غير محدود، فما اسمها؟");
            r1.setText("كرة السلة");
            r2.setText("كرة اليد");
            r3.setText("كرة الطائرة");
            r4.setText("البولو");
            right=r2;
        }
        else if(Integer.valueOf(page.getText().toString())==2){
            quest.setText("بعد الإنذار الثاني يُطرد اللاعب من المباراة ولا يلعب في المباراة التالية لفريقه، فما اسم هذه الرياضة؟");
            r1.setText("كرة القدم");
            r2.setText("الكريكيت");
            r3.setText("كرة القدم الأمريكية");
            r4.setText("كرة اليد");
            right=r1;
        }
        else if(Integer.valueOf(page.getText().toString())==3){
            quest.setText("في هذه اللعبة لاعبين وخيول، فما اسمها؟");
            r1.setText("البولو");
            r2.setText("السكواش");
            r3.setText("الرجبي");
            r4.setText("الغولف");
            right=r1;
        }
        else if(Integer.valueOf(page.getText().toString())==4){
            quest.setText("في هذه اللعبة لا يلبس اللاعب خوذة لحماية رأسه، ويمرر الكرة لفريقه إلى الخلف، فما اسمها؟");
            r1.setText("الكريكيت");
            r2.setText("كرة الطائرة الشاطئية");
            r3.setText("كرة القدم الأمريكية");
            r4.setText("الرجبي");
            right=r4;
        }
        else if(Integer.valueOf(page.getText().toString())==5){
            quest.setText(" في هذه اللعبة تُستخدم كلمة 'love' بدلاً من رقم صفر، فما هي؟ ");
            r1.setText("الغولف");
            r2.setText("كرة التنس الأرضي");
            r3.setText("الملاكمة");
            r4.setText("سباق الخيول");
            right=r2;
        }
        else if(Integer.valueOf(page.getText().toString())==6){
            quest.setText("مدة الجري التي يستغرقها المتسابقين في هذه اللعبة قد تصل إلى ساعتين أو أكثر بقليل، فما اسمها؟");
            r1.setText("رياضة المشي");
            r2.setText("سباق فورميلا ون");
            r3.setText("الماراثون");
            r4.setText("البيسبول");
            right=r3;
        }
        else if(Integer.valueOf(page.getText().toString())==7){
            quest.setText("في هذه اللعبة يتحرك اللاعبون بشكل دائري لليمين ليتبادلوا لمس الكرة بعد أن يلمسها واحدٌ منهم، فما هي؟");
            r1.setText("التنس الأرضي");
            r2.setText("كرة اليد");
            r3.setText("كرة الطائرة");
            r4.setText("البيسبول");
            right=r3;
        }
        else if(Integer.valueOf(page.getText().toString())==8){
            quest.setText("اسم بطولة هذه اللعبة 'كأس ستانلي'، فما هي؟");
            r1.setText("التنس الأرضي");
            r2.setText("الهوكي");
            r3.setText("كرة القدم الأمريكية");
            r4.setText("سباق تور دي فرانس");
            right=r2;
        }
        else if(Integer.valueOf(page.getText().toString())==9){
            quest.setText("في هذه اللعبة، يُسمح لكل لاعب في البطولة أن يحمل معه 14 مضرباً، فما اسمها؟");
            r1.setText("السكواش");
            r2.setText("البولو");
            r3.setText("الكريكيت");
            r4.setText("الغولف");
            right=r4;
        }
        else if(Integer.valueOf(page.getText().toString())==10){
            quest.setText("الكرة في هذه اللعبة تكون ثقيلة ويجب أن تمر على ممر طوله 60 قدماً، فما اسمها؟");
            r1.setText("الغولف");
            r2.setText("السكواش");
            r3.setText("البولينغ");
            r4.setText("كرة السلة");
            right=r3;
        }

        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r1,right);
            }
        });
        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r2,right);
            }
        });
        r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r3,right);
            }
        });
        r4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct(r4,right);
            }
        });

    }



/////////////////////////////////////////////////////////////////////////////////
    //next question
    public void next(){
        r1.setBackgroundResource(R.drawable.custom_button);
        r2.setBackgroundResource(R.drawable.custom_button);
        r3.setBackgroundResource(R.drawable.custom_button);
        r4.setBackgroundResource(R.drawable.custom_button);
        pg=pg+1;

        if(pg==11){result();}
        else if(pg<11){
            page.setText(String.valueOf(pg));
            if(category.category==1){b1();}
            else if(category.category==2){b2();}
            else if(category.category==4){b4();}
            else if(category.category==5){b5();}
        }
        else if(pg>11){
            Toast.makeText(getApplicationContext(),"لقد أنهيت جميع الأسئلة",Toast.LENGTH_LONG).show();
        }


    }

    public void correct(Button b1, Button b2){
        if(b1.getId()==b2.getId()){
            numberright++;
            b2.setBackgroundColor(Color.GREEN);
        }
        else if(b1.getId()!=b2.getId()){
            b2.setBackgroundColor(Color.GREEN);
            b1.setBackgroundColor(Color.RED);
        }

    }

    public void result(){
        Intent i = new Intent(this, result.class);
        startActivity(i);
    }


    /////////////////////////////////////////////////////////////////////////
    //repeat button
    public void repeat(){
        pg=1;
        page.setText(String.valueOf(pg));
        numberright=0;
        if(category.category==1){b1();}
        else if(category.category==2){b2();}
        else if(category.category==4){b4();}
        else if(category.category==5){b5();}
    }
}
